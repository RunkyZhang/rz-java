package com.rz.s.boot.demo.application.cache;

import lombok.Data;

@Data
public class Tow {
    private String value;
    private int count;
}
